#!/bin/bash
while true
do
	python3 manage.py push_to_fb;
done
