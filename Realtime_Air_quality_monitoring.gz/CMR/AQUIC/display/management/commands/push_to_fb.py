from django.core.management.base import BaseCommand
from display.models import Value
import pyrebase

config = {
  "apiKey": "AIzaSyBvMbaT6pHO-G8fSP_fb4hgaUOrO0vtc_4",
  "authDomain": "qpac-f4fc5.firebaseapp.com",
  "databaseURL": "https://aqpac-f4fc5.firebaseio.com",
  "storageBucket": "qpac-f4fc5.appspot.com",
}

firebase = pyrebase.initialize_app(config)
db = firebase.database()


class Command(BaseCommand):
    help = 'Pushes unchecked values to firebase'

    def handle(self, *args, **kwargs):
        val_of_node= Value.objects.order_by('date')
        for val in val_of_node:
            if val.check==0:
                date = val.date
                a="'"
                data_of_1 = {"temperature": a+str(val.nox)+a,
                            "humidity": a+str(val.so2)+a,
                            "lpg": a+str(val.lpg)+a,
                            "propane": a+str(val.propane)+a,
                            "carbon_monoxide": a+str(val.carbon_monoxide)+a,
                            "carbon_dioxide": a+str(val.carbon_dioxide)+a,
                            "ammonia": a+str(val.ammonia)+a,
                            "methane": a+str(val.methane)+a,
                            "alcohol": a+str(val.alcohol)+a,
                            "smoke": a+str(val.smoke)+a,
                            "dust": a+str(val.dust)+a,
                            "date":a+str(date)+a
                }
                db.child("users").child(str(val.date)+"_"+str(val.time_of_the_day)).set(data_of_1)
                val.check = 1
                val.save()
