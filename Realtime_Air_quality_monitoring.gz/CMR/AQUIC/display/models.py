from django.db import models
from  django.utils import timezone

class Value(models.Model):
    id_no = models.IntegerField(default=0)
    check = models.IntegerField(default=0)
    time_of_the_day = models.IntegerField(default=0)
    lpg = models.FloatField(default=-1)
    so2 = models.FloatField(default=-1)
    nox = models.FloatField(default=-1)
    propane = models.FloatField(default=-1)
    carbon_monoxide = models.FloatField(default=-1)
    carbon_dioxide = models.FloatField(default=-1)
    ammonia =  models.FloatField(default=-1)
    methane =  models.FloatField(default=-1)
    alcohol =  models.FloatField(default=-1)
    smoke =  models.FloatField(default=-1)
    dust =  models.FloatField(default=-1)
    date = models.DateField(default = timezone.now)

    def update(self):
        self.save()

    def __str__(self):
        return str(self.date) + "_" + str(self.time_of_the_day)
