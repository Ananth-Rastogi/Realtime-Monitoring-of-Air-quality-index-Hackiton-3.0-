from django.shortcuts import render
from django.http import HttpResponse as hr
from .models import Value
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse as jr
import pyrebase


# Create your views here.
config = {
  "apiKey": "AIzaSyBvMbaT6pHO-G8fSP_fb4hgaUOrO0vtc_4",
  "authDomain": "qpac-f4fc5.firebaseapp.com",
  "databaseURL": "https://aqpac-f4fc5.firebaseio.com",
  "storageBucket": "qpac-f4fc5.appspot.com",
}

firebase = pyrebase.initialize_app(config)
db = firebase.database()


def value_list(request):

    val_of_node= Value.objects.order_by('date')
    for val in val_of_node:
        if val.check==0:
            date = val.date
            a="'"
            data_of_1 = {"temperature": a+str(val.nox)+a,
                        "humidity": a+str(val.so2)+a,
                        "lpg": a+str(val.lpg)+a,
                        "propane": a+str(val.propane)+a,
                        "carbon_monoxide": a+str(val.carbon_monoxide)+a,
                        "carbon_dioxide": a+str(val.carbon_dioxide)+a,
                        "ammonia": a+str(val.ammonia)+a,
                        "methane": a+str(val.methane)+a,
                        "alcohol": a+str(val.alcohol)+a,
                        "smoke": a+str(val.smoke)+a,
                        "dust": a+str(val.dust)+a,
                        "date":a+str(date)+a
            }
            db.child("users").child(str(val.date)+"_"+str(val.time_of_the_day)).set(data_of_1)
            val.check = 1
            val.save()

    val_of_node1= Value.objects.filter(id_no=1).order_by('date')
    val_of_node2= Value.objects.filter(id_no=2).order_by('date')
    return render(request, 'display/index.html', {'val1':val_of_node1,'val2':val_of_node2})

from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def post(request):
    if(request.method=='POST'):
        b=request.body
        print(b)
        b = str(b).split("~")

        val_id_1 = str(b[0])
        val_id_2 = str(b[1])

        val_id_1 = str(val_id_1).split()

        id1 = int(str(val_id_1[0]).split("=")[1])
        dust1 = float(str(val_id_1[1]).split("=")[1])
        lpg1 = float(str(val_id_1[2]).split("=")[1])
        prop1 = float(str(val_id_1[3]).split("=")[1])
        print(id1, dust1,lpg1,prop1)
        a = Value.objects.create(id_no=id1, dust=dust1,lpg=lpg1, propane=prop1)
        print(a)
        a.save()
        try:
            val_id_2 = str(val_id_2).split()
            print(val_id_2)
            id2 = int(str(val_id_2[0]).split("=")[1])
            lpg2 = float(str(val_id_2[1]).split("=")[1])
            propane2 = float(str(val_id_2[2]).split("=")[1])
            methane2 = float(str(val_id_2[3]).split("=")[1])
            alcohol2 = float(str(val_id_2[4]).split("=")[1])
            smoke2 = float(str(val_id_2[5]).split("=")[1])
            co2 = float(str(val_id_2[6]).split("=")[1])
            co22 = float(str(val_id_2[7]).split("=")[1])
            ammonia2 = float(str(val_id_2[8]).split("=")[1])
            so22 = float(str(val_id_2[9]).split("=")[1])
            nox2 = float(str(val_id_2[10]).split("=")[1][:-2:])

            k = Value.objects.create(id_no=id2, lpg=lpg2, propane=propane2, so2=so22,carbon_monoxide=co2, carbon_dioxide=co22,ammonia=ammonia2,nox=nox2,methane=methane2,alcohol=alcohol2,smoke=smoke2)
            k.save()
        except Exception as e:
            #     # # Value.objects.create(id=, dust=b[], text='Test')
            pass
            return hr(100)

    return hr(100)

def get_data(request):
    val_of_node1= Value.objects.filter(id_no=1).order_by('date_time')
    for val in val_of_node1:
        if val.check==0:
            data_of_1 = {"temperature": str(val.temp),
                        "humidity": str(val.humidity),
                        "lpg": str(val.lpg),
                        "propane": str(val.propane),
                        "carbon_monoxide": str(val.carbon_monoxide),
                        "carbon_dioxide": str(val.carbon_dioxide),
                        "ammonia": str(val.ammonia),
                        "methane": str(val.methane),
                        "alcohol": str(val.alcohol),
                        "smoke": str(val.smoke),
                        "dust": str(val.dust),
                    }
    return jr(data_of_1)
