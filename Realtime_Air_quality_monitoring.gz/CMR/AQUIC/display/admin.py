from django.contrib import admin
from .models import Value

# Register your models here.
admin.site.register(Value)
